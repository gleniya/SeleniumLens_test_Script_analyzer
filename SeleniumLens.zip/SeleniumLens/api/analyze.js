import crypto from "crypto"

const cache = new Map()
export default async function handler(req, res) {
  const startTime = performance.now()
// Allow only POST
if(req.method !== 'POST'){

res.setHeader('Allow','POST')

return res.status(405).json({
error:"Only POST requests allowed"
})
}

try{

const { script } = req.body
if(!script || script.trim().length === 0){

return res.status(400).json({
error:"No Selenium script provided"
})

}

// Prevent very large requests
if(script.length > 15000){

return res.status(400).json({
error:"Script too large"
})

}

// Create script fingerprint
const hash = crypto
.createHash('sha256')
.update(script)
.digest('hex')

// Return cached result if exists
if(cache.has(hash)){

return res.status(200).json(
cache.get(hash)
)

}
const SYSTEM_PROMPT = `You are SeleniumLens, an expert Selenium test automation analyzer. 
Analyze the given Selenium script and return ONLY valid JSON (no markdown, no backticks, no explanation).

Return exactly this structure:
{
  "summary": {
    "score": <0-100 quality score>,
    "grade": "<A/B/C/D/F>",
    "totalIssues": <number>,
    "errors": <count>,
    "warnings": <count>,
    "infos": <count>
  },
  "issues": [
    {
      "type": "<ERROR|WARNING|INFO>",
      "category": "<LOCATOR|TIMING|NAMING|STRUCTURE|ASSERTION|DRIVER|BEST_PRACTICE>",
      "title": "<short title>",
      "snippet": "<relevant code snippet, max 60 chars>",
      "description": "<what is wrong>",
      "suggestion": "<how to fix it with example if possible>",
      "line": <approximate line number or null>
    }
  ],
  "positives": ["<thing done well>", ...],
  "refactoredHint": "<one key refactoring suggestion in 1-2 sentences>"
}

Issue categories explained:
- LOCATOR: Fragile XPath, no IDs, absolute paths, brittle selectors
- TIMING: Thread.sleep, missing waits, hardcoded delays
- NAMING: Poor method/variable names like test1, temp, x
- STRUCTURE: Missing Page Object Model, test setup/teardown issues
- ASSERTION: Missing assertions, weak assertions
- DRIVER: Driver management issues, missing quit/close
- BEST_PRACTICE: General Selenium anti-patterns

Be thorough and specific. Identify ALL issues present.`
//call ai
const response = await fetch(
'https://api.openai.com/v1/chat/completions',
{

method:'POST',

headers:{
'Content-Type':'application/json',
'Authorization':`Bearer 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`
},

body:JSON.stringify({

model:'gpt-4.1-nano',

messages:[

{
role:'system',
content:SYSTEM_PROMPT
},

{
role:'user',
content:`Analyze this Selenium script:\n\n${script}`
}

],

response_format:{type:"json_object"},
temperature:0.2,
max_tokens:800

})

})
if(response.status === 429){

return res.status(429).json({
error:"Rate limit reached"
})

}

if(!response.ok){

return res.status(500).json({
error:"AI request failed"
})

}

const data = await response.json()

// Store in cache
cache.set(hash,data)

// Return result
const endTime = performance.now()

console.log(
`Analysis completed in ${(endTime - startTime).toFixed(2)} ms`
)

return res.status(200).json(data)

}catch(error){

return res.status(500).json({

error:"Analysis failed"

})

}

}