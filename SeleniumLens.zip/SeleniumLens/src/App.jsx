import { useState, useRef } from 'react'
import './App.css'

const SAMPLE_SCRIPT = `public class LoginTest {
    @Test
    public void test1() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://example.com/login");

        driver.findElement(By.xpath("/html/body/div[2]/form/input[1]")).sendKeys("admin");
        driver.findElement(By.xpath("/html/body/div[2]/form/input[2]")).sendKeys("password123");
        
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("/html/body/div[2]/form/button")).click();
        
        Thread.sleep(3000);
        
        String title = driver.getTitle();
        assert title.equals("Dashboard");
        
        driver.quit();
    }
}`


export default function App() {
  const [script, setScript] = useState(SAMPLE_SCRIPT)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [activeTab, setActiveTab] = useState('all')
  const outputRef = useRef(null)
  const lastCallRef = useRef(0)
  const [refactoredCode,setRefactoredCode]=useState(null)

// maintainbility/flakiness/complexity/technicalDebt/stabilityScore
const analyzeMetrics = (script)=>{

const lines = script.split('\n').length

const sleeps = (script.match(/Thread.sleep/g)||[]).length

const xpaths = (script.match(/By.xpath/g)||[]).length

const waits = (script.match(/WebDriverWait/g)||[]).length

const actions = (script.match(/findElement/g)||[]).length


let maintainability = 100

maintainability -= sleeps * 10
maintainability -= xpaths * 5
maintainability -= lines > 50 ? 10 : 0

let flakiness = 0

flakiness += sleeps * 20
flakiness += xpaths * 10
flakiness -= waits * 10

let complexity = actions + (lines/10)

let stabilityScore =
flakiness>40?50:
flakiness>20?70:90

let overallScore = Math.round(

maintainability * 0.35 +

(100 - flakiness) * 0.25 +

(Math.max(0, 100 - complexity * 2)) * 0.15 +

stabilityScore * 0.25

)

overallScore = Math.max(0, Math.min(100, overallScore))
let grade = "F"

if(overallScore >= 90)
grade = "A"

else if(overallScore >= 80)
grade = "B"

else if(overallScore >= 70)
grade = "C"

else if(overallScore >= 60)
grade = "D"
return{
grade,

maintainability:Math.max(0,maintainability),

flakinessRisk:
flakiness>40?"HIGH":
flakiness>20?"MEDIUM":"LOW",

complexity:
complexity>30?"HIGH":
complexity>15?"MEDIUM":"LOW",

technicalDebt:
maintainability<60?"HIGH":
maintainability<80?"MEDIUM":"LOW",

stabilityScore,

overallScore,

health:

overallScore>80?"GOOD":
overallScore>60?"FAIR":"POOR",

risk:

flakiness>40?"HIGH":
flakiness>20?"MEDIUM":"LOW"



}

}
//detect static issues func
const detectStaticIssues = (script)=>{

let issues=[]

if(script.includes("Thread.sleep")){

issues.push({

type:"WARNING",

category:"TIMING",

title:"Hard wait detected",

snippet:"Thread.sleep()",

description:
"Hard waits cause flaky tests",

suggestion:
"Use WebDriverWait",

line:null

})

}

if(script.includes("/html/")){

issues.push({

type:"WARNING",

category:"LOCATOR",

title:"Absolute XPath",

snippet:"/html/",

description:
"Absolute XPath is fragile",

suggestion:
"Use relative XPath",

line:null

})

}

return issues

}
// refactor generator function
const generateRefactor = (script)=>{

let improved = script

// Replace sleeps
improved = improved.replace(
/Thread.sleep\(.*\);/g,
'WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));'
)

// Replace xpath usage example
improved = improved.replace(
/By.xpath/g,
'By.cssSelector'
)

return improved

}
// run analysis func
const runAnalysis = async () => {
  

if (loading) return

if (!script.trim()) return

const now = Date.now()

// prevent spam requests (5 sec cooldown)
if(now - lastCallRef.current < 5000){
setError("Please wait 5 seconds before running another analysis")
return
}

lastCallRef.current = now

setLoading(true)
setError(null)
setResult(null)
const metrics = analyzeMetrics(script)
    try {
      const response = await fetch('/api/analyze', {

method:'POST',

headers:{
'Content-Type':'application/json'
},

body:JSON.stringify({

script

})

})
      
if(response.status === 429){

setError("Rate limit reached. Wait 10 seconds.")
setLoading(false)
return

}

if(!response.ok){

throw new Error("API failed")

}
const data = await response.json()
if(data.error){

setError(data.error)
setLoading(false)
return

}

if(!data.choices){

setError("Invalid response")
setLoading(false)
return

}
const text = data.choices?.[0]?.message?.content || ''
let parsed

try{

parsed = JSON.parse(text)

}catch{

setError("Failed to parse analysis result")
setLoading(false)
return

}
const staticIssues =
detectStaticIssues(script)

setResult({

...parsed,

issues:[
...staticIssues,
...parsed.issues
],

metrics

}) 
      setTimeout(() => outputRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
    } catch (err) {
      setError('Analysis failed. Check your API key or try again.')
      console.error(err)
    } finally {
      setLoading(false)
    }

  }

  const filteredIssues = result?.issues?.filter(i => {
    if (activeTab === 'all') return true
    return i.type === activeTab
  }) || []

  const typeConfig = {
    ERROR: { color: 'var(--error)', bg: 'var(--error-bg)', icon: '⚠', label: 'Error' },
    WARNING: { color: 'var(--warn)', bg: 'var(--warn-bg)', icon: '◉', label: 'Warning' },
    INFO: { color: 'var(--info)', bg: 'var(--info-bg)', icon: 'ℹ', label: 'Info' },
  }

  const categoryIcons = {
    LOCATOR: '🎯', TIMING: '⏱', NAMING: '✏️', STRUCTURE: '🏗',
    ASSERTION: '✓', DRIVER: '🔧', BEST_PRACTICE: '⭐'
  }

  const gradeColor = { A: '#10b981', B: '#3b82f6', C: '#f59e0b', D: '#f97316', F: '#ef4444' }

  return (
    <div className="app">
      {/* Background grid */}
      <div className="bg-grid" />

      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <div className="logo-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="16 18 22 12 16 6" /><polyline points="8 6 2 12 8 18" />
              </svg>
            </div>
            <div>
              <span className="logo-name">SeleniumLens</span>
              <span className="logo-tag">Script Analyzer</span>
            </div>
          </div>
          <nav className="nav-pills">
            <span className="pill">Selenium 4.x</span>
            <span className="pill">Java</span>
            <span className="pill pill-accent">AI-Powered</span>
          </nav>
        </div>
      </header>

      <main className="main">
        {/* Hero */}
        <section className="hero">
          <div className="hero-eyebrow">Test Quality Intelligence</div>
          <h1 className="hero-title">Find what breaks your<br /><span className="gradient-text">Selenium tests</span></h1>
          <p className="hero-sub">Paste your script. Get instant AI-powered analysis of locators, timing, naming, and best practices.</p>
        </section>

        {/* Editor Panel */}
        <div className="panel editor-panel">
          <div className="panel-header">
            <div className="panel-title">
              <span className="dot dot-red" /><span className="dot dot-yellow" /><span className="dot dot-green" />
              <span className="panel-label">Selenium Script</span>
            </div>
            <div className="panel-actions">
              <button className="btn-ghost" onClick={() => { setScript(''); setResult(null) }}>Clear</button>
              <button className="btn-ghost" onClick={() => setScript(SAMPLE_SCRIPT)}>Load Sample</button>
            </div>
          </div>
          <div className="editor-wrap">
            <div className="line-numbers">
              {script.split('\n').map((_, i) => (
                <span key={i}>{i + 1}</span>
              ))}
            </div>
            <textarea
              className="editor"
              value={script}
              onChange={e => setScript(e.target.value)}
              spellCheck={false}
              placeholder="Paste your Selenium test script here..."
            />
          </div>
          <div className="panel-footer">
            <span className="stat">{script.split('\n').length} lines · {script.length} chars</span>
            <button className="btn-analyze" onClick={runAnalysis} disabled={loading || !script.trim()}>
              {loading ? (
                <><span className="spinner" /> Analyzing...</>
              ) : (
                <><span className="run-icon">▶</span> Run Analysis</>
              )}
            </button>
          </div>
        </div>

        {/* Loading state */}
        {loading && (
          <div className="loading-block">
            <div className="loading-bar"><div className="loading-fill" /></div>
            <p>Scanning for issues · Checking locators · Evaluating patterns...</p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="error-block">
            <span>⚠</span> {error}
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="results" ref={outputRef}>

            {/* Score card */}
            <div className="score-row">
              <div className="score-card">
                <div className="score-grade" style={{ color: gradeColor[result.summary.grade] || '#fff' }}>
                  {result.metrics?.grade}
                </div>
                <div>
                  <div className="score-number">{result.metrics?.overallScore}<span>/100</span></div>
                  <div className="score-label">Quality Score</div>
                </div>
              </div>
              <div className="tally-cards">
                <div className="tally error">
                  <span className="tally-num">{result.summary.errors}</span>
                  <span className="tally-label">Errors</span>
                </div>
                <div className="tally warn">
                  <span className="tally-num">{result.summary.warnings}</span>
                  <span className="tally-label">Warnings</span>
                </div>
                <div className="tally info">
                  <span className="tally-num">{result.summary.infos}</span>
                  <span className="tally-label">Info</span>
                </div>
                <div className="tally total">
                  <span className="tally-num">{result.summary.totalIssues}</span>
                  <span className="tally-label">Total</span>
                </div>
              </div>
            </div>

            {/* Refactored hint */}
            {result.refactoredHint && (
              <div className="hint-banner">
                <span className="hint-icon">💡</span>
                <span>{result.refactoredHint}</span>
              </div>
            )}
            {result && (
              <button
                className="btn-ghost"
                onClick={()=>{

                const improved =
                generateRefactor(script)

                setRefactoredCode(improved)

                }}
                >

                Generate Improved Version

                </button>
             )}
            <div className="panel">
            <h2 className="section-title">
            Overall Test Quality
            </h2>

            <div className="score-row">

            <div className="score-card">

            <div
            className="score-number"
            style={{
            fontSize:"42px",
            color:
            result.metrics?.overallScore>80
            ?"#10b981":
            result.metrics?.overallScore>60
            ?"#f59e0b"

            :"#ef4444"

            }}
            >

            {result.metrics?.overallScore || "-"}
            <span>/100</span>

            </div>

            <div className="score-label">

            Overall Quality

            </div>

            </div>

            <div className="tally-cards">

            <div className="tally">

            <span className="tally-num">
            <span
            style={{
            color:

            result.metrics?.health==="GOOD"
            ?"#10b981":

            result.metrics?.health==="FAIR"
            ?"#f59e0b"

            :"#ef4444"
            }}
            >

            {result.metrics?.health || "-"}

            </span>
          

            </span>

            <span className="tally-label">

            Test Health

            </span>

            </div>

            <div className="tally">

            <span className="tally-num">

            <span
            style={{
            color:

            result.metrics?.health==="GOOD"
            ?"#10b981":

            result.metrics?.health==="FAIR"
            ?"#f59e0b"

            :"#ef4444"
            }}
            >

            {result.metrics?.health || "-"}

            </span>

            </span>

            <span className="tally-label">

            Risk Level

            </span>

            </div>

            </div>

            </div>

            </div>
            
        <div className="panel">
              <h2 className="section-title">
              Quality Metrics
              </h2>

          <div className="tally-cards">

              <div className="tally">

              <span className="tally-num">
              {result.metrics?.maintainability || "-"}
              </span>
              <span className="tally-label">
              Maintainability
              </span>
              </div>

              <div className="tally">
              <span className="tally-num"
              style={{
              color:
              result.metrics?.technicalDebt==="HIGH"
              ?"#ef4444":
              result.metrics?.technicalDebt==="MEDIUM"
              ?"#f59e0b"
              :"#10b981"

              }}

              >

              {result.metrics?.technicalDebt || "-"}

              </span>
              <span className="tally-label">
              Technical Debt
              </span>
              </div>

              <div className="tally">
              <span className="tally-num"
              style={{
              color:
              result.metrics?.stabilityScore<60
              ?"#ef4444":
              result.metrics?.stabilityScore<80
              ?"#f59e0b"
              :"#10b981"

              }}

              >

              {result.metrics?.stabilityScore || "-"}%

              </span>
              <span className="tally-label">
              Stability
              </span>
              </div>

              <div className="tally">
              <span 
                className="tally-num"
                style={{
                color:
                result.metrics?.flakinessRisk==="HIGH"
                ?"#ef4444":
                result.metrics?.flakinessRisk==="MEDIUM"
                ?"#f59e0b"
                :"#10b981"
                }}
                >

                {result.metrics?.flakinessRisk || "-"}
                </span>
              <span className="tally-label">
              Flakiness Risk
              </span>
              </div>

              <div className="tally">
              <span className="tally-num"
              style={{
              color:
              result.metrics?.complexity==="HIGH"
              ?"#ef4444":

              result.metrics?.complexity==="MEDIUM"
              ?"#f59e0b"

              :"#10b981"

              }}
              >

              {result.metrics?.complexity || "-"}

              </span>
              <span className="tally-label">
                Complexity
                </span>

                </div>

                </div>

             </div>      

            {/* Issues */}
            <div className="panel issues-panel">
              <div className="issues-header">
                <h2 className="section-title">Issues Found</h2>
                <div className="tab-group">
                  {['all', 'ERROR', 'WARNING', 'INFO'].map(t => (
                    <button
                      key={t}
                      className={`tab ${activeTab === t ? 'tab-active' : ''}`}
                      onClick={() => setActiveTab(t)}
                    >
                      {t === 'all' ? `All (${result.summary.totalIssues})` :
                        t === 'ERROR' ? `Errors (${result.summary.errors})` :
                        t === 'WARNING' ? `Warnings (${result.summary.warnings})` :
                        `Info (${result.summary.infos})`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="issue-list">
                {filteredIssues.length === 0 && (
                  <div className="empty-state">No issues in this category 🎉</div>
                )}
                {filteredIssues.map((issue, idx) => {
                  const cfg = typeConfig[issue.type] || typeConfig.INFO
                  return (
                    <div key={idx} className="issue-card" style={{ '--issue-color': cfg.color, '--issue-bg': cfg.bg, animationDelay: `${idx * 60}ms` }}>
                      <div className="issue-top">
                        <div className="issue-badges">
                          <span className="badge-type" style={{ color: cfg.color, background: cfg.bg }}>{issue.type}</span>
                          <span className="badge-cat">{categoryIcons[issue.category] || '•'} {issue.category}</span>
                          {issue.line && <span className="badge-line">L{issue.line}</span>}
                        </div>
                        <div className="issue-title">{issue.title}</div>
                        {issue.snippet && (
                          <code className="issue-snippet">{issue.snippet}</code>
                        )}
                      </div>
                      <div className="issue-body">
                        <div className="issue-desc">{issue.description}</div>
                        <div className="issue-fix">
                          <span className="fix-icon">✓</span>
                          <span>{issue.suggestion}</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
            {/* Refactored Code Panel */}
            {refactoredCode && (
            <div className="panel">
            <h2 className="section-title">
            Refactored Code
            </h2>
            <button
              className="btn-ghost"
              style={{marginBottom:"10px"}}
              onClick={()=>{

              navigator.clipboard.writeText(refactoredCode)

              }}
              >

              Copy Code

              </button>
            <div className="editor-wrap">
            <textarea
            className="editor"
            value={refactoredCode}
            readOnly
            style={{
            minHeight:"250px"
            }}
            />
            </div>
            </div>
            

            )}
            
            {/* Positives */}
            {result.positives?.length > 0 && (
              <div className="panel positives-panel">
                <h2 className="section-title">✓ What's Good</h2>
                <ul className="positives-list">
                  {result.positives.map((p, i) => (
                    <li key={i} className="positive-item">
                      <span className="positive-dot" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="footer">
        <span>SeleniumLens · Powered by OpenAI · Built for QA Engineers</span>
      </footer>
    </div>
  )
}
